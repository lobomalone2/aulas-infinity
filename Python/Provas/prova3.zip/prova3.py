def media(numero1,numero2,numero3):
    soma = numero1 + numero2 + numero3
    divisao = soma /3

    return print(f'a média é: {divisao}')

media(12,14,15)

